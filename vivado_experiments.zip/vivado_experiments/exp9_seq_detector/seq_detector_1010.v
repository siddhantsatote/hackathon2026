// Experiment 9: 1010 Sequence Detector - Mealy Machine (Overlapping)

module seq_detector_1010 (
  input  bit clk, rst_n, x,
  output z
);
  parameter A = 4'h1;
  parameter B = 4'h2;
  parameter C = 4'h3;
  parameter D = 4'h4;

  bit [3:0] state, next_state;

  // State register
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
      state <= A;
    else
      state <= next_state;
  end

  // Next state logic (Mealy)
  always @(state or x) begin
    case (state)
      A: begin
        if (x == 0) next_state = A;
        else        next_state = B;
      end
      B: begin
        if (x == 0) next_state = C;
        else        next_state = B;
      end
      C: begin
        if (x == 0) next_state = A;
        else        next_state = D;
      end
      D: begin
        if (x == 0) next_state = C;
        else        next_state = B;
      end
      default: next_state = A;
    endcase
  end

  // Output logic (Mealy: output depends on state AND input)
  assign z = (state == D) && (x == 0) ? 1 : 0;

endmodule
